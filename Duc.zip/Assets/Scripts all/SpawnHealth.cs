using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnHealth : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] private GameObject HealthBar;
    //[SerializeField] private GameObject Character;
    void Start()
    {
        GameObject newHealthBar = Instantiate(HealthBar, transform.position, transform.rotation) as GameObject;
        newHealthBar.transform.SetParent(GameObject.FindGameObjectWithTag("Health").transform, false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
