using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float Hitpoint;
    public float MaxHitPoint = 5;
    public HealthBarBehavior HealthBar;
    // Start is called before the first frame update
    void Start()
    {
        Hitpoint = MaxHitPoint;
        HealthBar.SetHealth(Hitpoint,MaxHitPoint);
    }

    // Update is called once per frame
    void Update()
    {
 
    }
    public void TakeHit(float dmg){
        Hitpoint -=dmg;
        if(Hitpoint<=0)
        {
            Destroy(gameObject);
        }
    }
}
